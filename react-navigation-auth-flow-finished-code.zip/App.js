import App from "./app/index";
export default App;
