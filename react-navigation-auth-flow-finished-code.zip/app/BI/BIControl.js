import Echarts from "native-echarts";
import React from "react";
import { View } from "native-base";
import HTML from "react-native-render-html";
import { StyleSheet } from "react-native";

import { Table, Row, Rows } from "react-native-table-component";

export default class BIControl {
  dataSourceConfig = [];
  data = {};
  drawControl(data, dataSourceConfig, drilldown = null) {}
  static getBIControl(el) {
    if (el == null) {
      return null;
    }
    switch (el) {
      case "text":
        return new BIText();
      case "grid":
        return new BIGrid();
      case "chartcolumn":
        return new BIChartColumn();
      case "chartpie":
        return new BIChartPie();
    }
  }
}

class BIChartColumn extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    debugger;
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Series = this.data.Series || null;
    if (Series == null) return;

    var Category = this.data.Category || null;
    if (Category == null) return;

    if (drilldown == true) {
      Category = this.data.DrillDown || Category;
    }
    var groupOpt = {
      field: Category,
      aggregates: []
    };
    var series = [];
    var ser = Series.split(",");

    for (var i = 0; i < ser.length; i++) {
      for (var j = 0; j < dataSourceConfig.length; j++) {
        if (
          DataSource == dataSourceConfig[j].IDQuery &&
          ser[i] == dataSourceConfig[j].Name
        ) {
          series.push({
            field: dataSourceConfig[j].Name,
            name: dataSourceConfig[j].Text,
            categoryField: Category
          });

          groupOpt.aggregates.push({
            field: dataSourceConfig[j].Name,
            aggregate: "sum"
          });
          break;
        }
      }
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj[Category] in res)) {
            res.__array.push((res[obj[Category]] = obj));
          } else {
            var i = 0;
            for (i; i < ser.length; i++) {
              res[obj[Category]][ser[i]] += obj[ser[i]];
            }
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b[ser[0]] - a[ser[0]];
      });

    let Data_value = [];
    let dataName = result.map((results, index, result) => {
      return results[Category];
    });

    //tạo danh sách data

    for (var i = 0; i < ser.length; i++) {
      Data_value.push({
        name: ser[i],
        type: "bar",
        data: []
      });
      for (var j = 0; j < result.length; j++) {
        Data_value[i].data.push(result[j][ser[i]]);
      }
    }

    var option = {
      title: {
        text: this.data.Title,
        subtext: this.data.Title,
        x: "center"
      },
      //color: ["#003366", "#006699", "#4cabce", "#e5323e"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      legend: {
        data: dataName
      },
      toolbox: {},
      calculable: true,
      grid: {
        left: "3%",
        right: "4%",
        bottom: "10%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          axisTick: { show: false },
          data: dataName,
          axisLabel: {
            rotate: 45
          }
        }
      ],
      yAxis: [
        {
          type: "value"
        }
      ],
      series: Data_value
    };
    var key = Math.random();
    return (
      <View style={{ flex: 1, backgroundColor: "yellow" }} key={key}>
        <Echarts option={option} />
      </View>
    );
  }
}

class BIText extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    return (
      <View style={{ flex: 1, backgroundColor: "green" }} key={key}>
        <HTML html={this.data.text} />
      </View>
    );
  }
}
class BIGrid extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Columns = this.data.Columns || null;
    if (Columns == null) return;

    var columns = [];
    var cols = Columns.split(",");

    for (var i = 0; i < cols.length; i++) {
      for (var j = 0; j < dataSourceConfig.length; j++) {
        if (
          DataSource == dataSourceConfig[j].IDQuery &&
          cols[i] == dataSourceConfig[j].Name
        ) {
          var o = {
            field: dataSourceConfig[j].Name,
            title: dataSourceConfig[j].Text
          };
          columns.push(o);
          break;
        }
      }
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj[Category] in res)) {
            res.__array.push((res[obj[Category]] = obj));
          } else {
            var i = 0;
            for (i; i < cols.length; i++) {
              res[obj[Category]][cols[i]] += obj[cols[i]];
            }
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b[ser[0]] - a[ser[0]];
      });

    var value = [];
    for (var i = 0; i < data.length; i++) {
      value.push({ data: [] });
      for (var j = 0; j < cols.length; j++) {
        value[i].data.push(data[i][cols[j]]);
      }
    }

    debugger;
    let dataGrid = [];
    for (const e in value) {
      dataGrid.push(value[e].data);
    }

    let nameHearder = [];
    for (const item in columns) {
      nameHearder.push(columns[item].title);
    }
    var key = Math.random();
    return (
      <View style={styles.container} key={key}>
        <Table borderStyle={{ borderWidth: 2, borderColor: "#c8e1ff" }}>
          <Row data={nameHearder} style={styles.head} textStyle={styles.text} />
          <Rows data={dataGrid} textStyle={styles.text} />
        </Table>
      </View>
    );
  }
  groupBy(xs, f) {
    return xs.reduce(
      (r, v, i, a, k = f(v)) => ((r[k] || (r[k] = [])).push(v), r),
      {}
    );
  }
}

class BIChartPie extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Field = this.data.Field || null;
    if (Field == null) return;

    var Category = this.data.Category || null;
    if (Category == null) return;

    if (drilldown == true) {
      Category = this.data.DrillDown || Category;
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj[Category] in res)) {
            res.__array.push((res[obj[Category]] = obj));
          } else {
            res[obj[Category]][Field] += obj[Field];
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b[Field] - a[Field];
      });
    var filedName = result.map((results, index, result) => {
      return results[Category];
    });
    var dataPie = [];
    for (var i = 0; i < result.length; i++) {
      dataPie.push({ value: result[i][Field], name: result[i][Category] });
    }

    var option = {
      title: {
        text: this.data.Title,
        subtext: this.data.Title,
        x: "center"
      },
      tooltip: {
        trigger: "item",
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      legend: {
        orient: "vertical",
        left: "left",
        data: filedName
      },
      series: [
        {
          name: "chart",
          type: "pie",
          radius: "55%",
          center: ["50%", "60%"],
          data: dataPie,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)"
            }
          }
        }
      ]
    };
    var key = Math.random();
    return (
      <View style={{ flex: 1, backgroundColor: "yellow" }} key={key}>
        <Echarts option={option} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: "#fff" },
  head: { height: 40, backgroundColor: "#f1f8ff" },
  text: { margin: 6 }
});
