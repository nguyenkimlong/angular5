export default class BIControl {
  dataSourceConfig = [];
  data = {};
  drawControl(data, dataSourceConfig, drilldown = null) {}
  static getBIControl(el) {
    if (el == null) {
      return null;
    }
    switch (el) {
      case "chartcolumn":
        return new BIChartColumn();
    }
  }
}

class BIChartColumn extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    debugger;
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Series = this.data.Series || null;
    if (Series == null) return;

    var Category = this.data.Category || null;
    if (Category == null) return;

    if (drilldown == true) {
      Category = this.data.DrillDown || Category;
    }
    var groupOpt = {
      field: Category,
      aggregates: []
    };
    var series = [];
    var ser = Series.split(",");

    for (var i = 0; i < ser.length; i++) {
      for (var j = 0; j < dataSourceConfig.length; j++) {
        if (
          DataSource == dataSourceConfig[j].IDQuery &&
          ser[i] == dataSourceConfig[j].Name
        ) {
          series.push({
            field: dataSourceConfig[j].Name,
            name: dataSourceConfig[j].Text,
            categoryField: Category
          });
          groupOpt.aggregates.push({
            field: dataSourceConfig[j].Name,
            aggregate: "sum"
          });
          break;
        }
      }
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj.ItemID in res)) {
            res.__array.push((res[obj.ItemID] = obj));
          } else {
            var i = 0;
            for (i; i < ser.length; i++) {
              res[obj.ItemID][ser[i]] += obj[ser[i]];
            }
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b.Quantity - a.Quantity;
      });

    var option = {
      //color: ["#003366", "#006699", "#4cabce", "#e5323e"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      legend: {
        data: ["Forest", "Steppe", "Desert", "Wetland"]
      },
      toolbox: {},
      calculable: true,
      grid: {
        left: "3%",
        right: "4%",
        bottom: "10%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          axisTick: { show: false },
          data: ["Forest", "Steppe", "Desert", "Wetland"],
          axisLabel: {
            rotate: 45
          }
        }
      ],
      yAxis: [
        {
          type: "value"
        }
      ],
      series: [
        {
          name: "Forest",
          type: "bar",
          barGap: 0,
          data: [320, 332, 301, 334]
        },
        {
          name: "Steppe",
          type: "bar",
          data: [220, 182, 191, 234]
        },
        {
          name: "Desert",
          type: "bar",
          data: [100, 140, 200, 240]
        }
      ]
    };
  }
}
