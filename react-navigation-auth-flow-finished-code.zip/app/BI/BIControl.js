import Echarts from "native-echarts";
import React from "react";
import { View } from "native-base";
import HTML from "react-native-render-html";
import { StyleSheet } from "react-native";

import { Table, Row, Rows } from "react-native-table-component";

export default class BIControl {
  dataSourceConfig = [];
  data = {};
  handleMessage = null;
  Controls = [];

  drawControl(data, dataSourceConfig, drilldown = null) {}
  static getBIControl(el) {
    if (el == null) {
      return null;
    }
    switch (el) {
      case "text":
        return new BIText();
      case "grid":
        return new BIGrid();
      case "chartbar":
        return new BIChartColumn();
      case "chartpie":
        return new BIChartPie();
      case "chartline":
        return new BIChartLine();
    }
  }
}

class BIChartColumn extends BIControl {
  controltype = "chartbar";
  drawControl(data, dataSourceConfig, drilldown = null) {
    debugger;
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Series = this.data.Series || null;
    if (Series == null) return;

    var Category = this.data.Category || null;
    if (Category == null) return;

    if (drilldown == true) {
      Category = this.data.DrillDown || Category;
    }
    var groupOpt = {
      GroupBy: Category,
      AgvFunc: []
    };
    var series = [];
    var ser = Series.split(",");

    for (var i = 0; i < ser.length; i++) {
      for (var j = 0; j < dataSourceConfig.length; j++) {
        if (
          DataSource == dataSourceConfig[j].IDQuery &&
          ser[i] == dataSourceConfig[j].Name
        ) {
          series.push({
            field: dataSourceConfig[j].Name,
            name: dataSourceConfig[j].Text,
            categoryField: Category
          });

          groupOpt.AgvFunc.push({
            Name: dataSourceConfig[j].Name,
            Type: "Sum"
          });
          break;
        }
      }
    }

    var result = [];
    // result = data
    //   .reduce(
    //     function(res, obj) {
    //       if (!(obj[Category] in res)) {
    //         res.__array.push((res[obj[Category]] = obj));
    //       } else {
    //         var i = 0;
    //         for (i; i < ser.length; i++) {
    //           res[obj[Category]][ser[i]] += obj[ser[i]];
    //         }
    //       }
    //       return res;
    //     },
    //     { __array: [] }
    //   )
    //   .__array.sort(function(a, b) {
    //     return b[ser[0]] - a[ser[0]];
    //   });

    result = _GroupBy(data, {
      GroupBy: [groupOpt.GroupBy],
      AgvFunc: groupOpt.AgvFunc
    });

    let Data_value = [];
    let dataName = result.map((results, index, result) => {
      return results[Category];
    });

    //tạo danh sách data

    for (var i = 0; i < ser.length; i++) {
      Data_value.push({
        name: ser[i],
        type: this.controltype.replace("chart", ""),
        data: []
      });
      for (var j = 0; j < result.length; j++) {
        Data_value[i].data.push(result[j][ser[i]]);
      }
    }

    var option = {
      title: {
        text: this.data.Title,
        subtext: this.data.Title,
        x: "center"
      },
      //color: ["#003366", "#006699", "#4cabce", "#e5323e"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      legend: {
        data: dataName
      },
      toolbox: {},
      calculable: true,
      grid: {
        left: "3%",
        right: "4%",
        bottom: "10%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          axisTick: { show: false },
          data: dataName,
          axisLabel: {
            rotate: 45
          }
        }
      ],
      yAxis: [
        {
          type: "value"
        }
      ],
      series: Data_value
    };
    var key = Math.random();
    return (
      <View style={{ flex: 1, backgroundColor: "yellow" }} key={key}>
        <Echarts
          option={option}
          handleMessage={this.handleMessage}
          control={this.data}
          Field={Category}
          owner={this}
          dataUpdate={data}
        />
      </View>
    );
  }
}

class BIText extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    return (
      <View style={{ flex: 1, backgroundColor: "green" }} key={key}>
        <HTML html={this.data.text} />
      </View>
    );
  }
}
class BIGrid extends BIControl {
  drawControl(data, dataSourceConfig, drilldown = null) {
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Columns = this.data.Columns || null;
    if (Columns == null) return;

    var columns = [];
    var cols = Columns.split(",");

    for (var i = 0; i < cols.length; i++) {
      for (var j = 0; j < dataSourceConfig.length; j++) {
        if (
          DataSource == dataSourceConfig[j].IDQuery &&
          cols[i] == dataSourceConfig[j].Name
        ) {
          var o = {
            field: dataSourceConfig[j].Name,
            title: dataSourceConfig[j].Text
          };
          columns.push(o);
          break;
        }
      }
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj[Category] in res)) {
            res.__array.push((res[obj[Category]] = obj));
          } else {
            var i = 0;
            for (i; i < cols.length; i++) {
              res[obj[Category]][cols[i]] += obj[cols[i]];
            }
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b[ser[0]] - a[ser[0]];
      });

    var value = [];
    for (var i = 0; i < data.length; i++) {
      value.push({ data: [] });
      for (var j = 0; j < cols.length; j++) {
        value[i].data.push(data[i][cols[j]]);
      }
    }

    debugger;
    let dataGrid = [];
    for (const e in value) {
      dataGrid.push(value[e].data);
    }

    let nameHearder = [];
    for (const item in columns) {
      nameHearder.push(columns[item].title);
    }
    var key = Math.random();
    return (
      <View style={styles.container} key={key}>
        <Table borderStyle={{ borderWidth: 2, borderColor: "#c8e1ff" }}>
          <Row data={nameHearder} style={styles.head} textStyle={styles.text} />
          <Rows data={dataGrid} textStyle={styles.text} />
        </Table>
      </View>
    );
  }
}

class BIChartPie extends BIControl {
  controltype = "chartpie";
  drawControl(data, dataSourceConfig, drilldown = null) {
    debugger;
    this.dataSourceConfig = dataSourceConfig;
    var DataSource = this.data.DataSource || null;
    if (DataSource == null) return;

    var Field = this.data.Field || null;
    if (Field == null) return;

    var Category = this.data.Category || null;
    if (Category == null) return;

    if (drilldown == true) {
      Category = this.data.DrillDown || Category;
    }

    var result = data
      .reduce(
        function(res, obj) {
          if (!(obj[Category] in res)) {
            //tạo mới từng đối tượng khi group , tránh cộng dồn data
            var objNew = {};

            objNew[Category] = obj[Category];
            objNew[Field] = obj[Field];
            res.__array.push((res[obj[Category]] = objNew));
          } else {
            res[obj[Category]][Field] += obj[Field];
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b[Field] - a[Field];
      });
    var filedName = result.map((results, index, result) => {
      return results[Category];
    });
    var dataPie = [];
    for (var i = 0; i < result.length; i++) {
      dataPie.push({ value: result[i][Field], name: result[i][Category] });
    }

    var option = {
      title: {
        text: this.data.Title,
        subtext: this.data.Title,
        x: "center"
      },
      tooltip: {
        trigger: "item",
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      legend: {
        orient: "vertical",
        left: "left",
        data: filedName
      },
      series: [
        {
          name: "chart",
          type: this.controltype.replace("chart", ""),
          radius: "55%",
          center: ["50%", "60%"],
          data: dataPie,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)"
            }
          }
        }
      ]
    };
    var key = Math.random();
    return (
      <View style={{ flex: 1, backgroundColor: "yellow" }} key={key}>
        <Echarts
          option={option}
          handleMessage={this.handleMessage}
          control={this.data}
          Field={Category}
          owner={this}
          dataUpdate={data}
        />
      </View>
    );
  }
}
class BIChartLine extends BIChartColumn {
  controltype = "chartline";
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: "#fff" },
  head: { height: 40, backgroundColor: "#f1f8ff" },
  text: { margin: 6 }
});

function _GroupBy(data, groupOption) {
  var dataNew = [];
  debugger;
  var check = function(curent) {
    for (var j = 0; j < dataNew.length; j++) {
      var m = {};
      for (var z = 0; z < groupOption.GroupBy.length; z++) {
        if (
          dataNew[j][groupOption.GroupBy[z]] != curent[groupOption.GroupBy[z]]
        ) {
          m = null;
          z = groupOption.GroupBy.length;
        }
      }

      if (m != null) return dataNew[j];
    }
    return null;
  };
  for (var i = 0; i < data.length; i++) {
    var cur = data[i];
    var checkCurrent = check(cur);
    if (checkCurrent == null) {
      //Neu khong ton tai tao model moi
      checkCurrent = {};
      for (var z = 0; z < groupOption.GroupBy.length; z++) {
        checkCurrent[groupOption.GroupBy[z]] = cur[groupOption.GroupBy[z]];
      }
      for (var z = 0; z < groupOption.AgvFunc.length; z++) {
        checkCurrent[groupOption.AgvFunc[z].Name] =
          cur[groupOption.AgvFunc[z].Name];
      }

      dataNew.push(checkCurrent);
    } else {
      for (var z = 0; z < groupOption.AgvFunc.length; z++) {
        if (groupOption.AgvFunc[z].Type == "Sum") {
          checkCurrent[groupOption.AgvFunc[z].Name] =
            checkCurrent[groupOption.AgvFunc[z].Name] +
            cur[groupOption.AgvFunc[z].Name];
        } else if (
          groupOption.AgvFunc[z].Type == "Max" &&
          checkCurrent[groupOption.AgvFunc[z].Name] <
            cur[groupOption.AgvFunc[z].Name]
        ) {
          checkCurrent[groupOption.AgvFunc[z].Name] =
            cur[groupOption.AgvFunc[z].Name];
        }
      }
    }
  }

  return dataNew;
}
