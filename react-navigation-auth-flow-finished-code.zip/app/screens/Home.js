import React from "react";
import {
  ScrollView,
  View,
  StyleSheet,
  Image,
  StatusBar,
  Platform
} from "react-native";

import { Icon, Button, Container, Header, Content, Left } from "native-base";

import HTML from "react-native-render-html";
import { isToken } from "../auth";
import Echarts from "native-echarts";
import { Table, Row, Rows } from "react-native-table-component";
import Expo from "expo";

import CustomHeader from "../Custom/CustomHeader";

import BIControl from "../BI/BIControl";

var json = require("../../data.json");
var jsonBI_sprPurchase = require("../../BI_sprPurchase.json");
var bicontrol;
var item = [];
export default class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      betoken: "",
      item: []
    };
    debugger;
    this._Load();
  }
  async componentWillMount() {
    await Expo.Font.loadAsync({
      Roboto: require("native-base/Fonts/Roboto.ttf"),
      Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf"),
      Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
    });
    this.setState({ loading: false });
  }
  _Load() {
    this.state.item = [];
    for (var i = 0; i < json.Controls.length; i++) {
      // bicontrol = new BIControl();
      bicontrol = BIControl.getBIControl(json.Controls[i].type);
      if (bicontrol == null) {
        alert("NoData");
      }
      var value = null;
      bicontrol.data = json.Controls[i].data;
      value = bicontrol.drawControl(jsonBI_sprPurchase || [], json.DataSource);
      this.state.item.push(value);
    }
  }

  componentDidMount() {
    isToken().then(res => {
      var token = res;
      this.setState({ betoken: token });
    });
  }
  handleMessage(a) {
    console.log("props ", a);
  }

  render() {
    if (this.state.loading) {
      return <Expo.AppLoading />;
    }
    return (
      <Container
        style={{
          paddingTop: Platform.OS === "ios" ? 0 : StatusBar.currentHeight,
          backgroundColor: "#03A9F4"
        }}
      >
        <CustomHeader
          title="Home"
          drawerOpen={() => this.props.navigation.navigate("DrawerOpen")}
          {...this.props}
        />

        <Content
          contentContainerStyle={{
            flex: 1
            // alignItems: "center",
            // justifyContent: "center",
            // padding: 10
          }}
        >
          <ScrollView style={{ flex: 1 }}>{this.state.item}</ScrollView>
        </Content>
      </Container>
    );
  }
}
