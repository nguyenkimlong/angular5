import React from "react";
import {
  ScrollView,
  View,
  StyleSheet,
  Image,
  StatusBar,
  Platform
} from "react-native";

import { Icon, Button, Container, Header, Content, Left } from "native-base";

import HTML from "react-native-render-html";
import { isToken } from "../auth";
import Echarts from "native-echarts";
import { Table, Row, Rows } from "react-native-table-component";
import Expo from "expo";

import CustomHeader from "../Custom/CustomHeader";

import BIControl from "../BI/BIControl";

var json = require("../../data.json");
var jsonBI_sprPurchase = require("../../BI_sprPurchase.json");
var bicontrol;
export default class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      betoken: "",
      data: [],
      tableHead: ["Head", "Head2", "Head3", "Head4"],
      tableData: [
        ["1111111111111", "211111212", "3121212", "41212121121212"],
        ["a", "b", "c", "d"],
        ["1", "2", "3", "456\n789"],
        ["a", "b", "c", "d"]
      ]
    };
    debugger;
    this._Load();
  }
  async componentWillMount() {
    await Expo.Font.loadAsync({
      Roboto: require("native-base/Fonts/Roboto.ttf"),
      Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf"),
      Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
    });
    this.setState({ loading: false });
  }
  _Load() {
    var item = [];
    for (var i = 0; i < json.Controls.length; i++) {
      // bicontrol = new BIControl();
      bicontrol = BIControl.getBIControl(json.Controls[i].type);
      if (bicontrol == null) {
        alert("NoData");
      }
      var a;
      bicontrol.data = json.Controls[i].data;
      bicontrol.drawControl(jsonBI_sprPurchase || [], json.DataSource);
      item.push(null);
    }
  }

  GetOptionChartColumn(key) {
    const option = {
      //color: ["#003366", "#006699", "#4cabce", "#e5323e"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      legend: {
        data: ["Forest", "Steppe", "Desert", "Wetland"]
      },
      toolbox: {},
      calculable: true,
      grid: {
        left: "3%",
        right: "4%",
        bottom: "10%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          axisTick: { show: false },
          data: ["Forest", "Steppe", "Desert", "Wetland"],
          axisLabel: {
            rotate: 45
          }
        }
      ],
      yAxis: [
        {
          type: "value"
        }
      ],
      series: [
        {
          name: "Forest",
          type: "bar",
          barGap: 0,
          data: [320, 332, 301, 334]
        },
        {
          name: "Steppe",
          type: "bar",
          data: [220, 182, 191, 234]
        },
        {
          name: "Desert",
          type: "bar",
          data: [100, 140, 200, 240]
        }
      ]
    };

    return (
      <View style={{ flex: 1, backgroundColor: "yellow" }} key={key}>
        <Echarts option={option} handleMessage={this.handleMessage} />
      </View>
    );
  }

  GetOptionText(text, key) {
    return (
      <View style={{ flex: 1, backgroundColor: "green" }} key={key}>
        <HTML html={text} />
      </View>
    );
  }

  GetOptionGrid(key) {
    const state = this.state;

    return (
      <View style={styles.container} key={key}>
        <Table borderStyle={{ borderWidth: 2, borderColor: "#c8e1ff" }}>
          <Row
            data={state.tableHead}
            style={styles.head}
            textStyle={styles.text}
          />
          <Rows data={state.tableData} textStyle={styles.text} />
        </Table>
      </View>
    );
  }

  GetBIControl() {
    debugger;
    var item = [];
    for (var i = 0; i < json.Controls.length; i++) {
      switch (json.Controls[i].type) {
        case "text":
          item.push(this.GetOptionText(json.Controls[i].data.Text, i));
          continue;
        case "chartcolumn":
          item.push(this.GetOptionChartColumn(i));
          continue;
        case "grid":
          item.push(this.GetOptionGrid(i));
          continue;
        case "chartpie":
          continue;
        case "chartline":
          continue;
        case "chartstock":
          continue;
        case "gauge":
          continue;
        case "map":
          continue;
        case "pivot":
          continue;
      }
    }
    return item;
  }
  componentDidMount() {
    isToken().then(res => {
      var token = res;
      this.setState({ betoken: token });
    });
  }
  handleMessage(a) {
    console.log("props ", a);
  }

  render() {
    var jsonBI_sprPurchase = require("../../BI_sprPurchase.json");
    var dataColumns;
    debugger;
    dataColumns = json.Controls[0].data.Series;

    var arr;
    var col = [];
    var item = [];

    var result = jsonBI_sprPurchase
      .reduce(
        function(res, obj) {
          if (!(obj.ItemID in res)) res.__array.push((res[obj.ItemID] = obj));
          else {
            res[obj.ItemID].Quantity += obj.Quantity;
          }
          return res;
        },
        { __array: [] }
      )
      .__array.sort(function(a, b) {
        return b.Quantity - a.Quantity;
      });

    var code = "";

    debugger;
    for (var i = 0; i < result.length; i++) {
      col.push(result[i]["Quantity"]);
      item.push(result[i]["ItemID"]);
    }

    if (this.state.loading) {
      return <Expo.AppLoading />;
    }
    return (
      <Container
        style={{
          paddingTop: Platform.OS === "ios" ? 0 : StatusBar.currentHeight,
          backgroundColor: "#03A9F4"
        }}
      >
        <CustomHeader
          title="Home"
          drawerOpen={() => this.props.navigation.navigate("DrawerOpen")}
          {...this.props}
        />

        <Content
          contentContainerStyle={{
            flex: 1
            // alignItems: "center",
            // justifyContent: "center",
            // padding: 10
          }}
        >
          <ScrollView style={{ flex: 1 }}>{this.GetBIControl()}</ScrollView>
        </Content>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: "#fff" },
  head: { height: 40, backgroundColor: "#f1f8ff" },
  text: { margin: 6 },
  icon: {
    width: 24,
    height: 24
  }
});
