import React from "react";
import {
  ScrollView,
  View,
  StyleSheet,
  Image,
  StatusBar,
  Platform
} from "react-native";

import { Icon, Button, Container, Header, Content, Left } from "native-base";

import HTML from "react-native-render-html";
import { isToken } from "../auth";
import Echarts from "native-echarts";
import { Table, Row, Rows } from "react-native-table-component";
import Expo from "expo";

import CustomHeader from "../Custom/CustomHeader";

import BIControl from "../BI/BIControl";

var json = require("../../data.json");
var bicontrol;
var item = [];
var filter = [];
var that = null;

export default class Home extends React.Component {
  constructor(props) {
    debugger;
    super(props);
    this.state = {
      loading: true,
      betoken: "",
      item: [],
      dataPurchase: null
    };

    const { navigation } = this.props;
    const itemId = navigation.getParam("itemId");
    filter = [];
    this.state.dataPurchase = [
      {
        ObjectID: "MOTO",
        DocumentDate: "2018-03-12T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 10,
        BPurcAmount: 200000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-04-09T00:00:00",
        ItemID: "BB-000010",
        ItemName: "Bao  giấy  10kg",
        Quantity: 2,
        BPurcAmount: 12000000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-04-09T00:00:00",
        ItemID: "BB-000003",
        ItemName: "Bao  giấy  5kg",
        Quantity: 0,
        BPurcAmount: 12000000
      },
      {
        ObjectID: "MOTO",
        DocumentDate: "2018-03-12T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 10,
        BPurcAmount: 200000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-04-02T00:00:00",
        ItemID: "BB-000002",
        ItemName: "Bao bộ heo nái",
        Quantity: 10,
        BPurcAmount: 6000000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-04-05T00:00:00",
        ItemID: "BB-000003",
        ItemName: "Bao  giấy  5kg",
        Quantity: 10,
        BPurcAmount: 10500000
      },
      {
        ObjectID: "20",
        DocumentDate: "2018-04-05T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 10,
        BPurcAmount: 200000000
      },
      {
        ObjectID: "085.0001",
        DocumentDate: "2018-04-10T00:00:00",
        ItemID: "BB-000002",
        ItemName: "Bao bộ heo nái",
        Quantity: 2,
        BPurcAmount: 300000
      },
      {
        ObjectID: "22",
        DocumentDate: "2018-04-10T00:00:00",
        ItemID: "BB-000006",
        ItemName: "Bao giấy  2 kg",
        Quantity: 3,
        BPurcAmount: 300000
      },
      {
        ObjectID: "MOTO",
        DocumentDate: "2018-05-28T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 10,
        BPurcAmount: 200000
      },
      {
        ObjectID: "B.MONGXUAN",
        DocumentDate: "2018-04-05T00:00:00",
        ItemID: "BB-000002",
        ItemName: "Bao bộ heo nái",
        Quantity: 10,
        BPurcAmount: 40000000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-04-23T00:00:00",
        ItemID: "BB-000003",
        ItemName: "Bao  giấy  5kg",
        Quantity: 20,
        BPurcAmount: 2000000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-05-28T00:00:00",
        ItemID: "BB-000002",
        ItemName: "Bao bộ heo nái",
        Quantity: 10,
        BPurcAmount: 1500000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-05-28T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 20,
        BPurcAmount: 2000000
      },
      {
        ObjectID: "001.0001",
        DocumentDate: "2018-05-28T00:00:00",
        ItemID: "BB-000001",
        ItemName: "Bao bộ heo thịt",
        Quantity: 20,
        BPurcAmount: 2000000
      }
    ];

    this._Load();
  }
  async componentWillMount() {
    await Expo.Font.loadAsync({
      Roboto: require("native-base/Fonts/Roboto.ttf"),
      Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf"),
      Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
    });
    this.setState({ loading: false });
  }

  _Load() {
    debugger;
    that = this;

    for (var i = 0; i < json.Controls.length; i++) {
      bicontrol = BIControl.getBIControl(json.Controls[i].type);
      if (bicontrol == null) {
        alert("NoData");
      }

      var value = null;
      bicontrol.data = json.Controls[i].data;
      if (bicontrol.handleMessage == null) {
        bicontrol.handleMessage = function(item) {
          debugger;
          var Bicontrol = this.owner;
          console.log(item);
          var Negative = null;
          item.control.Negative == undefined
            ? (Negative = 0)
            : (Negative = item.control.Negative);
          if (Negative != 0) {
            that._DrillDaw(item, Bicontrol, this.dataUpdate);
          }
        };
      }

      value = bicontrol.drawControl(
        this.state.dataPurchase || [],
        json.DataSource
      );
      this.state.item.push(value);
    }
  }

  _DrillDaw(e, bicontrols, dataFilter) {
    var updateData = [];
    filter.push({ name: e.name, field: e.field, data: bicontrols.data });
    // if (filter[0].data != bicontrol.data) {
    //   filter = [];
    //   filter.push({ name: e.name, field: e.field, data: bicontrols.data });
    // }
    var totalState = this.state.item.length;

    for (var j = 0; j < totalState; j++) {
      var value = null;
      this.bicontrol = BIControl.getBIControl(
        this.state.item[j].props.children.props.owner.controltype
      );
      this.bicontrol.data = this.state.item[j].props.children.props.control;

      if (e.control.Negative != 0) {
        if (this.bicontrol.handleMessage == null) {
          this.bicontrol.handleMessage = function(item) {
            var Bicontrol = this.owner;
            console.log(item);
            var Negative = null;
            item.control.Negative == undefined
              ? (Negative = 0)
              : (Negative = item.control.Negative);
            if (Negative != 0) {
              that._DrillDaw(item, Bicontrol, this.dataUpdate);
            }
          };
        }
        value = this.state.item[j];
        if (
          this.state.item[j].props.children.props.owner.data != bicontrols.data
        ) {
          this.bicontrol.data = this.state.item[j].props.children.props.control;
          var dataPurchase = dataFilter.filter(x => x[e.field] == e.name);

          value = this.bicontrol.drawControl(
            dataPurchase || [],
            json.DataSource
          );
        }

        if (
          this.state.item[j].props.children.props.owner.data.DrillDown != "" &&
          this.state.item[j].props.children.props.owner.data.DrillDown !=
            null &&
          this.state.item[j].props.children.props.owner.data.DrillDown
        ) {
          if (
            this.state.item[j].props.children.props.owner.data.DrillDown &&
            this.state.item[j].props.children.props.owner.data.DrillDown !=
              e.field &&
            this.state.item[j].props.children.props.owner.data ==
              bicontrols.data
          ) {
            filter = [];
            filter.push({
              name: e.name,
              field: e.field,
              data: bicontrols.data
            });
            this.bicontrol.data = bicontrols.data;
            var dataPurchase = this.state.dataPurchase.filter(
              x => x[filter[0].field] == filter[0].name
            );
            value = this.bicontrol.drawControl(
              dataPurchase,
              json.DataSource,
              true
            );
          }
        }
        //  else {
        //     // this.bicontrol.data = bicontrols.data;
        //     // var dataPurchase = this.state.dataPurchase.filter(
        //     //   x => x[filter[0].field] == filter[0].name
        //     // );

        //     value = this.state.item[j];

        //     // value = this.bicontrol.drawControl(
        //     //   dataPurchase,
        //     //   json.DataSource,
        //     //   true
        //     // );
        //   }
        updateData.push(value);
      }

      // if (e.control.DrillDown != "" && e.control.DrillDown != null) {
      //   if (e.control.DrillDown != e.field) {
      //     this.state.dataPurchase = this.state.dataPurchase.filter(
      //       x => x[e.field] == e.name
      //     );

      //     value = this.bicontrol.drawControl(
      //       this.state.dataPurchase,
      //       json.DataSource,
      //       true
      //     );
      //   }
      // }
    }
    this.setState({ item: updateData });
  }
  componentDidMount() {
    isToken().then(res => {
      var token = res;
      this.setState({ betoken: token });
    });
  }

  render() {
    if (this.state.loading) {
      return <Expo.AppLoading />;
    }
    return (
      <Container
        style={{
          paddingTop: Platform.OS === "ios" ? 0 : StatusBar.currentHeight,
          backgroundColor: "#03A9F4"
        }}
      >
        <CustomHeader
          title="Home"
          drawerOpen={() => this.props.navigation.navigate("DrawerOpen")}
          {...this.props}
        />

        <Content
          contentContainerStyle={{
            flex: 1
            // alignItems: "center",
            // justifyContent: "center",
            // padding: 10
          }}
        >
          <ScrollView style={{ flex: 1 }}>{this.state.item}</ScrollView>
        </Content>
      </Container>
    );
  }
}
