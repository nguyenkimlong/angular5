import React from "react";
import {
  Text,
  View,
  Container,
  Header,
  Content,
  Left,
  Body,
  Right,
  Icon,
  Title,
  List,
  ListItem,
  Item
} from "native-base";
import {
  StyleSheet,
  StatusBar,
  Platform,
  TouchableOpacity
} from "react-native";

export default class Category extends React.Component {
  constructor(props) {
    super(props);
    debugger;
    this.state = { product: [] };
  }
  goToView(guest) {
    debugger;
    alert(guest.name);
    this.props.navigation.navigate("Home", { itemId: guest.id });
  }
  render() {
    debugger;
    var product = [];
    for (var i = 0; i < 10; i++) {
      product.push({ id: i, name: "Apple" + i, price: "$" + i });
    }

    return (
      <Container
        style={{
          paddingTop: Platform.OS === "ios" ? 0 : StatusBar.currentHeight
        }}
      >
        <Header>
          <Left>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate("SignedIn");
              }}
            >
              <Icon type="FontAwesome" name="arrow-left" />
            </TouchableOpacity>
          </Left>
          <Body>
            <Title>Category</Title>
          </Body>
          <Right />
        </Header>
        <Content>
          <List
            key={Math.random()}
            dataArray={product}
            renderRow={item => (
              <ListItem
                button
                onPress={() => {
                  this.goToView(item);
                }}
              >
                <Text>
                  {item.name}
                  {item.price}
                </Text>
              </ListItem>
            )}
          />
        </Content>
      </Container>
    );
  }
}
