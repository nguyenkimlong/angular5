import React from "react";
import {
  Text,
  View,
  Container,
  Header,
  Content,
  Left,
  Body,
  Right,
  Icon,
  Title
} from "native-base";
import {
  StyleSheet,
  StatusBar,
  Platform,
  TouchableOpacity
} from "react-native";

export default class Category extends React.Component {
  constructor(props) {
    super(props);
    debugger;
  }

  render() {
    debugger;
    return (
      <Container
        style={{
          paddingTop: Platform.OS === "ios" ? 0 : StatusBar.currentHeight
        }}
      >
        <Header>
          <Left>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate("SignedIn");
              }}
            >
              <Icon type="FontAwesome" name="arrow-left" />
            </TouchableOpacity>
          </Left>
          <Body>
            <Title>Category</Title>
          </Body>
          <Right />
        </Header>
        <Content />
      </Container>
    );
  }
}
