import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  Platform,
  TouchableOpacity
} from "react-native";

import { Header, Body, Title, Content, Left, Icon, Right } from "native-base";

class CustomHeader extends Component {
  render() {
    const { navigate } = this.props.navigation;
    debugger;
    return (
      <Header>
        <StatusBar />       
          <Left>
            <Icon name="ios-menu"  onPress={() => this.props.drawerOpen()} />
          </Left>     

        <Body>
          <Title style={{ alignItems: "center" }}>{this.props.title}</Title>
        </Body>
        <Right>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate("Category")}
          >
            <Icon type="FontAwesome" name="angle-down" />
          </TouchableOpacity>
        </Right>
      </Header>
    );
  }
}
export default CustomHeader;
