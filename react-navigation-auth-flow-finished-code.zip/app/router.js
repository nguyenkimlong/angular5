import React from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  Dimensions,
  ScrollView,
  Image
} from "react-native";
import {
  StackNavigator,
  TabNavigator,
  SwitchNavigator,
  DrawerNavigator,
  DrawerItems,
  SafeAreaView
} from "react-navigation";
import { FontAwesome } from "react-native-vector-icons";

import SignUp from "./screens/SignUp";
import SignIn from "./screens/SignIn";
import Home from "./screens/Home";
import Profile from "./screens/Profile";
import Category from "./screens/Category";
import { View } from "native-base";

const headerStyle = {
  marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
};

export const SignedOut = StackNavigator({
  SignUp: {
    screen: SignUp,
    navigationOptions: {
      header: null,
      headerStyle
    },
    headerMode: "none"
  },
  SignIn: {
    screen: SignIn,
    navigationOptions: {
      header: null,
      headerStyle
    }
  },
  Category: {
    screen: Category
  }
});

// export const SignedIn1 = TabNavigator(
//   {
//     Home: {
//       screen: Home,
//       navigationOptions: {
//         tabBarLabel: "Home",
//         tabBarIcon: ({ tintColor }) => (
//           <FontAwesome name="home" size={30} color={tintColor} />
//         )
//       }
//     },
//     Profile: {
//       screen: Profile,
//       navigationOptions: {
//         tabBarLabel: "Profile",
//         tabBarIcon: ({ tintColor }) => (
//           <FontAwesome name="user" size={30} color={tintColor} />
//         )
//       }
//     }
//   },
//   {
//     tabBarOptions: {
//       style: {
//         paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
//       }
//     }
//   }
// );

const CustomDrawerContentComponent = props => (
  <ScrollView>
    <Image
      style={{
        flex: 1,
        height: 100,
        width: "100%",
        backgroundColor: "#2980b9"
      }}
      source={require("./images/logo.png")}
    />
    <SafeAreaView
      style={{ flex: 1, backgroundColor: "transparent" }}
      forceInset={{ top: "always", horizontal: "never" }}
    >
      <DrawerItems {...props} />
    </SafeAreaView>
  </ScrollView>
);
export const SignedIn = DrawerNavigator(
  {
    Home: {
      screen: Home,
      navigationOptions: {
        drawerLabel: "Home",
        drawerIcon: ({ tintColor }) => (
          <Image source={require("./icon/home.png")} style={styles.icon} />
        )
      }
    },
    Profile: {
      screen: Profile,
      navigationOptions: {
        drawerLabel: "Profile",
        drawerIcon: ({ tintColor }) => (
          <Image source={require("./icon/profile.png")} style={styles.icon} />
        )
      }
    }
  },
  {
    initialRouteName: "Home",
    // drawerWidth: Dimensions.get("window").width,
    // useNativeAnimations: false,
    contentComponent: CustomDrawerContentComponent,
    contentOptions: {
      // activeTintColor: "#e91e63",
      itemsContainerStyle: {
        marginVertical: 0
      },
      iconContainerStyle: {
        opacity: 1
      }
    }
  }
);

export const createRootNavigator = (signedIn = false) => {
  return SwitchNavigator(
    {
      SignedIn: {
        screen: SignedIn,
        navigationOptions: {
          header: {
            visible: false
          }
        }
      },
      SignedOut: {
        screen: SignedOut
      },
      Category: {
        screen: Category
      }
    },
    {
      initialRouteName: signedIn ? "SignedIn" : "SignedOut"
    }
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center"
  },
  drawerHeader: {
    height: 200,
    backgroundColor: "white"
  },
  drawerImage: {
    height: 150,
    width: 150,
    borderRadius: 75
  },
  icon: {
    width: 24,
    height: 24
  }
});
